#!/usr/bin/env python
#! -*- encoding: utf8 -*-

"""
1.- Pig Latin

Nombre Alumno:

Nombre Alumno:
"""

import sys

def is_vowel(letter):
    vowels_lowercase = 'aAeEiIoOuUyY'
    if letter in vowels_lowercase:
        return True
    return False

def is_lowercase(letter):
    if letter >= 'A' and letter <= 'Z':
        return True
    return False

def piglatin_word_init(string):
    if string[-1] in ',.;:!?':
        aux = string[-1];
        return piglatin_word_init(string[:-1]) + aux[0]
    else:
        return piglatin_word(string)       

def piglatin_word(word):
    """
    Esta función recibe una palabra en inglés y la traduce a Pig Latin

    :param word: la palabra que se debe pasar a Pig Latin
    :return: la palabra traducida
    """
    if word[0].isalpha():
        if is_vowel(word[0]):
            if (not is_lowercase(word[0])):
                return word+'yay'
            else:
                return word+'YAY'
        else:
            if (not is_lowercase(word[0])):
                aux = word
                flag = True
                i = 0
                while flag:
                    if (not is_vowel(word[i])): 
                        aux = aux[1:]
                        aux+=word[i]
                    else: 
                        flag = False
                    i = i + 1
                return aux+'ay'
            else:
                if (not is_lowercase(word[-1])):
                    word = word.lower()
                    aux = word
                    flag = True
                    i = 0
                    while flag:
                        if (not is_vowel(word[i])): 
                            aux = aux[1:]
                            aux+=word[i]
                        else: 
                            flag = False
                            aux = ''.join(aux[0].upper())+aux[1:]
                        i = i + 1
                    return aux+'ay'
                else:
                    aux = word
                    flag = True
                    i = 0
                    while flag:
                        if (not is_vowel(word[i])): 
                            aux = aux[1:]
                            aux+=word[i]
                        else: 
                            flag = False
                        i = i + 1
                    return aux+'AY'
    else:
        return word
    return word


def piglatin_sentence(sentence):
    """
    Esta función recibe una frase en inglés i la traduce a Pig Latin

    :param sentence: la frase que se debe pasar a Pig Latin
    :return: la frase traducida
    """
    aux = list()
    for i in sentence.split():
        aux = aux.append(piglatin_word_init(i))
    return  ' '.join(aux)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        print(piglatin_sentence(sys.argv[1]))
    else:
        while True:
            # COMPLETAR
            pass
