#! -*- encoding: utf8 -*-

from operator import itemgetter
import re
import sys

clean_re = re.compile('\W+')
def clean_text(text):
    return clean_re.sub(' ', text)

def sort_dic(d):
    for key, value in sorted(d.items(), key=lambda a: (-a[1], a[0])):
        yield key, value

def text_statistics(filename, to_lower=True, remove_stopwords=True, ex_tra=False):
    file1 = open(filename, 'r')
    stopwordlist = open('stopwords_en.txt', 'r')
    stopwordfinal = ''

    for l in stopwordlist:
        stopwordfinal = stopwordfinal + l + '\n'


    textofinal = ''
    numlineas = 0
    for l in file1:
        numlineas = numlineas + 1
        textofinal = textofinal + l + '\n'

    textofinal = clean_text(textofinal)
    if to_lower:
        textofinal = textofinal.lower()
    textofinal = textofinal.split()

    numwords = 0
    numwordsNS = 0
    numletter = 0
    dw={}
    dl={}
    dpw={}
    dpl={}
    for w in textofinal:
        for l in w:
            numletter = numletter + 1
            dl[l] = dl.get(l, 0) + 1
        numwords = numwords + 1
        if remove_stopwords:
            if w.lower() not in stopwordfinal:
                numwordsNS = numwordsNS + 1
                dw[w] = dw.get(w, 0) + 1
        else:
            dw[w] = dw.get(w, 0) + 1
    numwordsD = len(dw.keys())
    numletterD = len(dl.keys())

    if extra: 
        textobigramas = ''
        textobigramas1 = ''
        file1 = open(filename, 'r')
        for l in file1:
            textobigramas = textobigramas + ' $ ' +  clean_text(l) + '\n'
        

        if to_lower:
            textobigramas = textobigramas.lower()


        textobigramas = textobigramas.split()
        print(textobigramas)

        for x in range(len(textobigramas) - 1):
            bigrama = textobigramas[x] + ' ' + textobigramas[x+1]
            for l in range(len(textobigramas[x]) - 1):
                bisimbolo = textobigramas[x][l] + textobigramas[x][l+1]
                dpl[bisimbolo] = dpl.get(bisimbolo, 0) + 1
            if remove_stopwords:
                if textobigramas[x].lower() not in stopwordfinal and textobigramas[x+1].lower() not in stopwordfinal:
                    dpw[bigrama] = dpw.get(bigrama, 0) + 1
            else:
                dpw[bigrama] = dpw.get(bigrama, 0) + 1


    print('Lines: ' + str(numlineas))
    print('Number words: (with stopwords): ' + str(numwords))
    if remove_stopwords:
        print('Number words (without stopwords): ' + str(numwordsNS))
    print('Vocabulary size: ' + str(numwordsD))
    print('Number of symbols: ' + str(numletter))
    print('Number of different symbols: ' + str(numletterD))
    print('Words (alphabetical order):')
    for k in sorted(dw.keys()):
        print('\t' + k + ':\t' + str(dw[k]))
    print('Words (by frequency):')
    for k in sort_dic(dw):
        print('\t' + str(k[0]) + ':\t' + str(k[1]))
    print('Symbols (alphabetical order):')
    for k in sorted(dl.keys()):
        print('\t' + k + ':\t' + str(dl[k]))
    print('Symbols (by frequency):')
    for k in sort_dic(dl):
        print('\t' + str(k[0]) + ':\t' + str(k[1]))
    if extra:
        print('Word pairs (alphabetical order):')
        for k in sorted(dpw.keys()):
            print('\t' + k + ':\t' + str(dpw[k]))
        print('Word pairs (by frequency):')
        for k in sort_dic(dpw):
            print('\t' + str(k[0]) + ':\t' + str(k[1]))
        print('Symbol pairs (alphabetical order):')
        for k in sorted(dpl.keys()):
            print('\t' + k + ':\t' + str(dpl[k]))
        print('Symbol pairs (by frequency):')
        for k in sort_dic(dpl):
            print('\t' + str(k[0]) + ':\t' + str(k[1]))




def syntax():
    print ("\n%s filename.txt [to_lower?[remove_stopwords?]\n" % sys.argv[0])
    sys.exit()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        syntax()
    name = sys.argv[1]
    lower = False
    stop = False
    if len(sys.argv) > 2:
        lower = (sys.argv[2] in ('1', 'True', 'yes'))
        if len(sys.argv) > 3:
            stop = (sys.argv[3] in ('1', 'True', 'yes'))
            if len(sys.argv) > 4:
                extra = (sys.argv[4] in ('extra', 'Extra', 'EXTRA'));

    text_statistics(name, to_lower=lower, remove_stopwords=stop, ex_tra=extra)







