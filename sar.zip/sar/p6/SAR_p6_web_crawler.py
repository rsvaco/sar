import bs4
import colorama
from random import randrange
import re
import requests
from requests.exceptions import SSLError, ReadTimeout, ConnectTimeout, ConnectionError
import sys
from urllib.parse import urljoin, urlsplit, urlunsplit
import hashlib
import time

colorama.init() # only necessary in windows
OK = colorama.Fore.GREEN
ERROR = colorama.Fore.RED
BLUE = colorama.Fore.BLUE
BACKRED = colorama.Back.RED
RESET = colorama.Style.RESET_ALL
doc_text = {}
doc_cortesia = {}
ampliacion = False
WORDS=[]

MAX_TOKEN_LEN = 15
CLEAN_RE = re.compile('\W+')

#######################
## WORKING WITH URLS ##
#######################

def get_site(url):
    return urlsplit(url).netloc



###############################
## WORKING WITH HTML CONTENT ##
###############################

def download_web(url):
    print('Getting "%s" ... ' % url, end='')
    try:
        r = requests.get(url, timeout=1)
        print(OK + 'ok!' + RESET)
    except (SSLError, ReadTimeout, ConnectTimeout, ConnectionError) as err:
        print(ERROR + 'ERROR: %s' % err + RESET)
        return None
    return bs4.BeautifulSoup(r.text,  'lxml')#'html.parser')

def extract_urls(contenido, baseurl):
    url_list = []
    for link in contenido.find_all('a'):
        newurl = link.get('href')
        if newurl is None:
            continue
        full_new_url = urljoin(baseurl, newurl.strip())
        surl = urlsplit(full_new_url)
        if surl.scheme in ['http', 'https']:
            ext = surl.path[surl.path.rfind('.'):].lower()
            if ext not in [".pdf", ".jpg"]:
                newurl = urlunsplit((surl.scheme, surl.netloc, surl.path, '', ''))
                url_list.append(newurl)
    return url_list

def extract_text(content):
    return CLEAN_RE.sub(' ', content.text).lower()



############################
## WORKING WITH THE INDEX ##
############################

def add_processed_url(url_dic, url):
    """Anyade url al diccionario de documentos (url_dic)

    Args:
        url_dic: el diccionario de documentos
        url: la url que se debe anyadir

    Returns:
        int: el docid de url dentro del diccionario

    """
    key = len(url_dic.keys())
    url_dic[key] = url
    return key

def get_next_url(url_queue):
    """Extrae una url de la cola de urls url_queue y la devuelve

    Args:
        url_queue: la cola de urls

    Returns:
        text: una url de la cola

    """
    if ampliacion: 
        global doc_cortesia
        next = url_queue.pop(0)
        site = get_site(next)
        esta=doc_cortesia.get(site, False)
        if esta == True:
            print("Esperando 1 segundo por cortesía")
            time.sleep(1)
            doc_cortesia = {}
            doc_cortesia[site]=True
            return next
        else:
            doc_cortesia[site]=True
            return next
    else:
        return url_queue.pop(0)

def add_pending_url(url_queue, url, url_dic):
    """Anyade url a la cola de urls si no esta todavia en ella o en el diccionario de documentos
    
        Args:
            url_queue: la cola de urls
            url: la url que se debe anyadir
            url_dic: el diccionario de documentos
    
        Returns:
            boolean: True si la url se ha anyadido. False si ya existia
        """
    res = False;
    keys = url_dic.keys()
    for k in keys:
        if url == url_dic[k]:
            return False
    if url in url_queue:
        return False

    url_queue.append(url)
    return True
    

def add_to_index(index, urlid, text):
    """Anyade el docid correscondiente a una url a las posting list de los terminos contenidos en text

        Args:
            index: el indice invertido
            urlid: el docid de la url
            text: el texto que se debe procesar

        Returns:
            int: numero de terminos procesador
    """
    if ampliacion:
        global doc_text
        h=hashlib.sha256()
        h.update(text.encode('utf-16be'))
        has=h.hexdigest()
        esta=doc_text.get(has, False)
        if esta == True:
            print("DUPLICADO")
            return 0
        else:
            doc_text[has]=True
            contiene_palabra = False
            for w in WORDS:            
                if w in text: 
                    contiene_palabra = True  
                    print("\t\tEste documento contiene " + OK + w + RESET) 
            
            if contiene_palabra == False:
                print("\t\tEste documento no es relevante")
                return 0
            
            cnt = 0
            text = text.split()
            for w in text:
                cnt = cnt + 1
                lista = index.get(w, [])
                if urlid not in lista:
                    lista.append(urlid)
                    index[w] = lista
            return cnt
    else:
        cnt = 0
        text = text.split()
        for w in text:
            cnt = cnt + 1
            lista = index.get(w, [])
            if urlid not in lista:
                lista.append(urlid)
                index[w] = lista
        return cnt

def get_posting(index, dic, term):
    """Devuelve una lista con todas las urls donde aparece un termino

        Args:
            index: el indice invertido
            dic: el diccionario de documento, necesario para obtener las urls a partir de los urlids
            term: el termino

        Returns:
            list: una lista con las urls donde aparece term, None si el termino no esta en el indice invertido
    """
    lista = []
    postings = index.get(term, [])
    if postings != []:
        for k in dic.keys():
            if k in postings:
                lista.append(dic[k])
        return lista
    else: 
        return None


###############
## SHOW INFO ##
###############


def info(index, processed, pending):
    print("\n====\nINFO\n====")
    # about de index
    print('Number of tokens:', len(index))
    print('Number of processed urls:', len(processed))
    if len(processed) != len(set(processed.values())):
        print (BACKRED + "ERROR: SOME URLS ARE DUPLICATED" + RESET)
    print('Number of pending urls:', len(pending))
    print('-' * 50)
    # searching words
    
    for word in WORDS:
        refs = get_posting(index, processed, word)
        if refs is None:
            print ("%s'%s'%s is not indexed" % (ERROR, word, RESET))
        else:
            print ("%s'%s'%s is in:" % (BLUE, word, RESET), ', '.join(sorted(refs)))
    print('-' * 50)
    # about the sites
    print(processed.values())
    l1 = sorted(set(get_site(url) for url in processed.values()))
    l2 = sorted(set(get_site(url) for url in pending_urls).difference(l1))
    max_len = max(len(s) for s in l1 + l2)
    l1 = ([s.ljust(max_len) for s in l1])
    l2 = ([s.ljust(max_len) for s in l2])
    print('Processed Sites (%d):' % len(l1))
    for i in range(int(len(l1)/4)+1):
        print('\t'+'\t'.join(l1[i*4:i*4+4]))
    print('-' * 50)
    print('Pending Sites (%d):' % len(l2))
    for i in range(int(len(l2)/4)+1):
        print('\t'+'\t'.join(l2[i*4:i*4+4]))


if __name__ == "__main__":
    MAX = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    if len(sys.argv) >= 3:
        if sys.argv[2] in ["ampliacion", "AMPLIACION", "extra"]:
            print("Ampliación activada")
            ampliacion = True
    if len(sys.argv) > 3:
        WORDS = sys.argv[3:]
        print(WORDS)
    else:
        WORDS = ["valencia", "upv", "google", "informática", "momento",
             "barcelona", "proyecto"]
        print(WORDS)
    inverted_index, processed_urls, pending_urls = {}, {}, []
    add_pending_url(pending_urls, "http://www.upv.es", processed_urls)
    for iter in range(MAX):
        url = get_next_url(pending_urls)
        print('(%d)' % iter, end=' ')
        page = download_web(url)
        if page is not None:
            urlid = add_processed_url(processed_urls, url)
            text = extract_text(page)
            add_to_index(inverted_index, urlid, text)
            url_list = extract_urls(page, url)
            for new_url in url_list:
                add_pending_url(pending_urls, new_url, processed_urls)
    info(inverted_index, processed_urls, pending_urls)
